package com.example.uts_isa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Nama;
    EditText NomorPendaftaran;
    Spinner Pilihan;
    CheckBox Daftar;
    Button Klik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Nama = findViewById(R.id.nama_lengkap);
        NomorPendaftaran = findViewById(R.id.nomorpendaftaran);
        Pilihan = findViewById(R.id.sebuah_pilihan);
        Daftar = findViewById(R.id.cb_Kdaftar);
        Klik = findViewById(R.id.btn_daftar);

        Klik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String NamaLengkap = Nama.getText().toString();
                String NomorOrang = NomorPendaftaran.getText().toString();
                String cetak = Daftar.getText().toString();
                String putar = String.valueOf(Pilihan.getSelectedItem());

                if (NamaLengkap.trim().equals("")) {
                    Nama.setError("Nama tidak boleh kosong!!!!!");
                }
                else if (NomorOrang.trim().equals("")) {
                    NomorPendaftaran.setError("Nomor Pendaftaran Tidak Boleh Kosong!!!!!!!!!!!!!!!!!!!!!!");
                }
                else if (!Daftar.isChecked()){
                    Toast.makeText(MainActivity.this,"Punten isi dulu pacc", Toast.LENGTH_SHORT).show();
                }
                else if (putar.equalsIgnoreCase("Jalur Pendaftaran")){
                    Toast.makeText(MainActivity.this, "Coy isi dulu", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent pindah = new Intent(MainActivity.this,SecondActivity.class);
                    pindah.putExtra("K_nama",NamaLengkap);
                    pindah.putExtra("K_nomor",NomorOrang);
                    pindah.putExtra("K_konfirmasi", cetak);
                    pindah.putExtra("K_pendaftaran", putar);
                    startActivity(pindah);

                }
            }
        });
    }
}